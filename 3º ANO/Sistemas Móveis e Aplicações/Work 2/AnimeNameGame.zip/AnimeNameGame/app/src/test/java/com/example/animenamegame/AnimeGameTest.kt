package com.example.animenamegame

import com.example.animenamegame.data.AnimePerguntas
import junit.framework.TestCase.assertEquals
import org.junit.Test

class AnimeGameTest {

    //Vejo se a pontuação aumenta com a resposta certa
    @Test
    fun testeRespostaCorreta() {
        var score = 0
        val question = AnimePerguntas(
            imageResId = R.drawable.naruto,
            correctAnswer = "Naruto",
            options = listOf("Naruto", "One Piece", "Bleach", "Dragon Ball")
        )

        if ("Naruto" == question.correctAnswer) {
            score++
        }

        assertEquals(1, score)
    }

    //Teste para ver se a pontuação não aumenta quando a resposta é errada
    @Test
    fun testRespostaIncorreta() {
        var score = 0
        val question = AnimePerguntas(
            imageResId = R.drawable.naruto,
            correctAnswer = "Naruto",
            options = listOf("Naruto", "One Piece", "Bleach", "Dragon Ball")
        )

        if ("One Piece" != question.correctAnswer) {
            //Não é suposto fazer nada neste caso, o meu score não pode aumentar
        }

        assertEquals(0, score)
    }
}