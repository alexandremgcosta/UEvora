package com.example.animenamegame.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun FimJogo(score: Int, nickname: String, onRestartClick: () -> Unit, onBackToStartClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Chegou ao fim do jogo, $nickname!",
            style = MaterialTheme.typography.headlineLarge,
            fontSize = 26.sp,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        Text(
            text = "O seu score foi: $score",
            style = MaterialTheme.typography.bodyLarge.copy(
                fontSize = 24.sp,
                color = Color.Black
            ),
            modifier = Modifier.padding(bottom = 26.dp)
        )
        Button(onClick = onRestartClick) {
            Text(text = "Reiniciar o Jogo", fontSize = 20.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onBackToStartClick) {
            Text(text = "Voltar ao Início", fontSize = 20.sp)
        }

    }
}