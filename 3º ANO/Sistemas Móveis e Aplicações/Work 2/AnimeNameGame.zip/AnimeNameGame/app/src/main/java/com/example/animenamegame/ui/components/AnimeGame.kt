package com.example.animenamegame.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.animenamegame.data.AnimePerguntas
import com.example.animenamegame.data.perguntasList


@Composable
fun AnimeGame(onBackToStartClick: () -> Unit, nickname: String) {
    var indexpergunta by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var fimdojogo by remember { mutableStateOf(false) }
    var perguntas by remember { mutableStateOf(perguntasList.shuffled()) }
    val scope = rememberCoroutineScope()

    fun restartGame() {
        indexpergunta = 0
        score = 0
        fimdojogo = false
        perguntas = perguntasList.shuffled()
    }


    if (fimdojogo){
        FimJogo(score = score, nickname= nickname, onRestartClick = { restartGame() }, onBackToStartClick = onBackToStartClick)
    }else if (indexpergunta < perguntas.size) {
        val perguntaatual = perguntas[indexpergunta]
        PerguntasAnime(
            question = perguntaatual,
            onOptionSelected = { selectedOption ->
                if (selectedOption == perguntaatual.correctAnswer) {
                    score++
                    indexpergunta++
                } else {
                    fimdojogo = true
                }
            }
        )
    } else {
        fimdojogo = true
    }
}

@Composable
fun PerguntasAnime(question: AnimePerguntas, onOptionSelected: (String) -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth(0.8f)
        ) {
            Column(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(id = question.imageResId),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.height(16.dp))
                question.options.forEach { option ->
                    Button(
                        onClick = { onOptionSelected(option) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text(text = option, fontSize = 20.sp, color = Color.White)
                    }
                }
            }
        }
    }
}