package com.example.animenamegame.data

data class AnimePerguntas(
    val imageResId: Int,
    val correctAnswer: String,
    val options: List<String>
)