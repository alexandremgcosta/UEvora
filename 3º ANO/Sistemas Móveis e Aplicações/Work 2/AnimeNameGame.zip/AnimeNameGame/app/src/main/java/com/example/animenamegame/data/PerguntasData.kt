package com.example.animenamegame.data

import com.example.animenamegame.R

val perguntasList = listOf(
    AnimePerguntas(
        imageResId = R.drawable.naruto,
        correctAnswer = "Naruto",
        options = listOf("Naruto", "One Piece", "Bleach", "Dragon Ball")
    ),
    AnimePerguntas(
        imageResId = R.drawable.onepiece,
        correctAnswer = "One Piece",
        options = listOf("Naruto", "One Piece", "Bleach", "Dragon Ball")
    ),
    AnimePerguntas(
        imageResId = R.drawable.bleach,
        correctAnswer = "Bleach",
        options = listOf("Naruto", "One Piece", "Bleach", "Dragon Ball")
    ),
    AnimePerguntas(
        imageResId = R.drawable.dragonball,
        correctAnswer = "Dragon Ball",
        options = listOf("Naruto", "One Piece", "Bleach", "Dragon Ball")
    ),
    AnimePerguntas(
        imageResId = R.drawable.attackontitan,
        correctAnswer = "Attack on Titan",
        options = listOf("Attack on Titan", "Fullmetal Alchemist", "Death Note", "Sword Art Online")
    ),
    AnimePerguntas(
        imageResId = R.drawable.fullmetal,
        correctAnswer = "Fullmetal Alchemist",
        options = listOf("Attack on Titan", "Fullmetal Alchemist", "Death Note", "Sword Art Online")
    ),
    AnimePerguntas(
        imageResId = R.drawable.deathnote,
        correctAnswer = "Death Note",
        options = listOf("Attack on Titan", "Fullmetal Alchemist", "Death Note", "Sword Art Online")
    ),
    AnimePerguntas(
        imageResId = R.drawable.sao,
        correctAnswer = "Sword Art Online",
        options = listOf("Attack on Titan", "Fullmetal Alchemist", "Death Note", "Sword Art Online")
    ),
    AnimePerguntas(
        imageResId = R.drawable.demonslayer,
        correctAnswer = "Demon Slayer",
        options = listOf("Demon Slayer", "Tokyo Ghoul", "My Hero Academia", "Hunter x Hunter")
    ),
    AnimePerguntas(
        imageResId = R.drawable.tokyoghoul,
        correctAnswer = "Tokyo Ghoul",
        options = listOf("Demon Slayer", "Tokyo Ghoul", "My Hero Academia", "Hunter x Hunter")
    ),
    AnimePerguntas(
        imageResId = R.drawable.myhero,
        correctAnswer = "My Hero Academia",
        options = listOf("Demon Slayer", "Tokyo Ghoul", "My Hero Academia", "Hunter x Hunter")
    ),
    AnimePerguntas(
        imageResId = R.drawable.hunterxhunter,
        correctAnswer = "Hunter x Hunter",
        options = listOf("Demon Slayer", "Tokyo Ghoul", "My Hero Academia", "Hunter x Hunter")
    ),
    AnimePerguntas(
        imageResId = R.drawable.onepunchman,
        correctAnswer = "One Punch Man",
        options = listOf("One Punch Man", "Mob Psycho 100", "Boku no Hero", "Black Clover")
    ),
    AnimePerguntas(
        imageResId = R.drawable.mobpsycho,
        correctAnswer = "Mob Psycho 100",
        options = listOf("One Punch Man", "Mob Psycho 100", "Boku no Hero", "Black Clover")
    ),
    AnimePerguntas(
        imageResId = R.drawable.blackclover,
        correctAnswer = "Black Clover",
        options = listOf("One Punch Man", "Mob Psycho 100", "Boku no Hero", "Black Clover")
    )
)