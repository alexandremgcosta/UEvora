package com.example.animenamegame

import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.example.animenamegame.ui.components.InicioJogo
import org.junit.Rule
import org.junit.Test

class InicioJogoTeste {


    @get:Rule
    val composeTestRule = createComposeRule()


    @Test
    fun testarBotaoIndisponivel() {
        composeTestRule.setContent {
            InicioJogo(onStartClick = {})
        }

        //Ele procura o componente que tem o texto "Iniciar o Jogo" e ve se esta desactivado
        composeTestRule.onNodeWithText("Iniciar o Jogo")
            .assertIsNotEnabled()
    }

}