import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Tabuleiro {
    private int n_prods1, n_prods2;
    int[][] tabuleiro;
    int[][] tabela_de_pares;

    Tabuleiro(int n_prods1, int n_prods2) {
        this.n_prods1 = n_prods1;
        this.n_prods2 = n_prods2;
        this.tabuleiro = new int[n_prods1 + 1][n_prods2 + 1];
        this.tabela_de_pares = new int[n_prods1 + 1][n_prods2 + 1];
    }

    void solucao(String[][] passadeira1, String[][] passadeira2) {
        final int MaxSoma = 200000;
        // Preencher os Casos Base
        tabuleiro[0][0] = 0;
        tabela_de_pares[0][0] = 0;

        for (int x = 1; x <= n_prods1; x++) {
            tabuleiro[x][0] = 0;
            tabela_de_pares[x][0] = 0;
        }
        for (int y = 1; y <= n_prods2; y++) {
            tabuleiro[0][y] = 0;
            tabela_de_pares[0][y] = 0;
        }

        for (int x = 1; x <= n_prods1; x++) {
            for (int y = 1; y <= n_prods2; y++) {
                int valorSoma = 0;
                int n_pares = 0;

                if (passadeira1[1][x - 1].equals(passadeira2[1][y - 1])) {
                    valorSoma = Integer.parseInt(passadeira1[2][x - 1]) + Integer.parseInt(passadeira2[2][y - 1]);
                    if(valorSoma > MaxSoma){valorSoma=MaxSoma;}

                    n_pares = tabela_de_pares[x - 1][y - 1] + 1;
                }

                if (tabuleiro[x][y - 1] > tabuleiro[x - 1][y]) {
                    if (tabuleiro[x][y - 1] == tabuleiro[x - 1][y - 1] + valorSoma) {
                        tabela_de_pares[x][y] = Math.min(tabela_de_pares[x][y - 1], n_pares);
                        tabuleiro[x][y] = tabuleiro[x][y - 1];
                    } else if (tabuleiro[x][y - 1] > tabuleiro[x - 1][y - 1] + valorSoma) {
                        tabuleiro[x][y] = tabuleiro[x][y - 1];
                        tabela_de_pares[x][y] = tabela_de_pares[x][y - 1];
                    } else {
                        tabuleiro[x][y] = tabuleiro[x - 1][y - 1] + valorSoma;
                        tabela_de_pares[x][y] = n_pares;
                    }

                } else if (tabuleiro[x - 1][y] > tabuleiro[x][y - 1]) {
                    if (tabuleiro[x - 1][y] == tabuleiro[x - 1][y - 1] + valorSoma) {
                        tabela_de_pares[x][y] = Math.min(tabela_de_pares[x - 1][y], n_pares);
                        tabuleiro[x][y] = tabuleiro[x - 1][y];
                    } else if (tabuleiro[x - 1][y] > tabuleiro[x - 1][y - 1] + valorSoma) {
                        tabuleiro[x][y] = tabuleiro[x - 1][y];
                        tabela_de_pares[x][y] = tabela_de_pares[x - 1][y];
                    } else {
                        tabuleiro[x][y] = tabuleiro[x - 1][y - 1] + valorSoma;
                        tabela_de_pares[x][y] = n_pares;
                    }

                } else {
                    tabela_de_pares[x][y] = Math.min(tabela_de_pares[x - 1][y], tabela_de_pares[x][y - 1]);

                    if (tabuleiro[x][y - 1] == tabuleiro[x - 1][y - 1] + valorSoma) {
                        /*if(tabela_de_pares[x-1][y-1] == 0){
                            tabuleiro[x][y] = tabuleiro[x][y - 1];
                        } else{
                            tabela_de_pares[x][y] = Math.min(tabela_de_pares[x][y], n_pares);
                            tabuleiro[x][y] = tabuleiro[x][y - 1];
                        }*/

                        tabuleiro[x][y] = tabuleiro[x][y-1];



                    } else if (tabuleiro[x][y - 1] > tabuleiro[x - 1][y - 1] + valorSoma) {
                        tabuleiro[x][y] = tabuleiro[x][y - 1];
                        tabela_de_pares[x][y] = tabela_de_pares[x][y];
                    } else {
                        tabuleiro[x][y] = tabuleiro[x - 1][y - 1] + valorSoma;
                        tabela_de_pares[x][y] = n_pares;
                    }
                }

            }
        }


        System.out.println(tabuleiro[n_prods1][n_prods2] + " " + tabela_de_pares[n_prods1][n_prods2]);
    }

}

class Main {
    public static void main(String[] args) throws NumberFormatException, IOException {

        String[][] passadeira1;
        String[][] passadeira2;
        final int MaxCases = 5;
        final int MaxProds = 2000;

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        int n_casos = Integer.parseInt(input.readLine());
        if(n_casos>5){n_casos=MaxCases;}

        while (n_casos != 0) {

            int n_prods1 = Integer.parseInt(input.readLine());
            if(n_prods1>MaxProds){n_prods1= MaxProds;}
            passadeira1 = new String[3][n_prods1];
            for (int i = 0; i < n_prods1; i++) {
                String[] linha = input.readLine().split(" ");
                passadeira1[0][i] = linha[0];
                passadeira1[1][i] = linha[1].substring(0,1).toUpperCase();
                passadeira1[2][i] = linha[2];
            }

            int n_prods2 = Integer.parseInt(input.readLine());
            passadeira2 = new String[3][n_prods2];
            if(n_prods2>MaxProds){n_prods2= MaxProds;}
            for (int j = 0; j < n_prods2; j++) {
                String[] linha = input.readLine().split(" ");
                passadeira2[0][j] = linha[0];
                passadeira2[1][j] = linha[1].substring(0,1).toUpperCase();
                passadeira2[2][j] = linha[2];
            }

            Tabuleiro t = new Tabuleiro(n_prods1, n_prods2);
            t.solucao(passadeira1, passadeira2);

            n_casos--;
        }
    }
}